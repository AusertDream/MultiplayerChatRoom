#pragma once
#include "framework.h"
#include "InitWindows.h"
using namespace std;


//�ͻ����ļ�



extern void StartClient();