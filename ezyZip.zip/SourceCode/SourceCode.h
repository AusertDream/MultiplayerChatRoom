﻿#pragma once

#include "resource.h"
#include "resource1.h" 